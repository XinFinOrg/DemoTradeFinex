		<!-- Global site tag (gtag.js) - Google Analytics -->
        <!-- <script async src="https://www.googletagmanager.com/gtag/js?id=UA-112396835-1"></script>
        <script type="text/javascript">
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            gtag('js', new Date());
            gtag('config', 'UA-112396835-1');
        </script> -->
		<div class="button-go-top">
			<a href="javascript:void(0)" title="" class="go-top"> <i class="fa fa-chevron-up"></i> </a><!-- /.go-top --> 
		</div>
		<div id="fadew" class="white_overlay"></div>
		<div id="fade" class="black_overlay"></div>
	</body>
</html>