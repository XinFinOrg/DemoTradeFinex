<section class="flat-row flat-main-blog blog_style contact_mainpage_sec">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="flat-row-title center">
					<p><img src="<?php echo base_url() ?>assets/images/icon/line.png" alt="icon"></p>
					<h2>Contact US</h2>
					<p>Learn more, schedule a demo, or speak with a member of our team. </p>
				</div>
				<!-- /.flat-row-title --> 
			</div>
			<!-- /.col-md-12 --> 
		</div>
		<div class="row">
			<div class="col-md-12">
				<div class="btn-more"> 
					<a href="<?php echo base_url() ?>publicv/contact" title="">Contact Us <span class="icon_right_margin"> <img src="<?php echo base_url() ?>assets/images/icon/arrow.png" alt="icon"></span></a> 
				</div>
			</div>
		</div>
		<!-- /.row --> 
	</div>
	<!-- /.container --> 
</section>